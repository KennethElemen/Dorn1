<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Purple Admin</title>
    <link rel="stylesheet" href="../assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="../assets/vendors/css/vendor.bundle.base.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="//code.tidio.co/rigk6wllgp396rgqayzic87xr1qljmk8.js" async></script>
    <link rel="stylesheet" href="../assets/css/nav.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="shortcut icon" href="../assets/images/favicon.ico" />
       <style>
       
      

    .custom-img {
        padding: 20px;
        height: 300px;
        object-fit: cover;
        width: 100%; /* Ensure the width is 100% to maintain responsiveness */
    }

     .custom-nav-link {
        font-size: 18px; /* Adjust the font size as needed */
        transition: color 0.3s ease; /* Add a smooth transition effect */
    }

    .custom-nav-link:hover {
        color: purple; /* Change the hover color to purple */
    }
    </style>
</head>
<body>   
  <nav class="navbar navbar-expand-lg navbar-light bg-white default-layout-navbar fixed-top">
            <div class="container">
                <a class="navbar-brand" href="../index.html">
                    <img src="../assets/images/DormBell.png" alt="logo" class="img-fluid" />
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">   
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="../Guest/availablerooms.php">
                                <p class="mb-0 text-lg custom-nav-link">Room</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../index.php">
                                <p class="mb-0 text-lg custom-nav-link">Login</p>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="container-fluid page-body-wrapper full-page-wrapper">


            <div class="content-wrapper d-flex align-items-center justify-content-center auth">
                <div class="main-container">
                   <div class="container-fluid">
                                <div class="col-20 text-center mb-4">
                                        <h2 class="display-1 p-20 ">AVAILABLE ROOMS</h2>
                                </div>
                    <div class="row">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-4 stretch-card grid-margin">
                                    <div class="card card-img-holder">
                                        <div id="carouselExample1" class="carousel slide" data-ride="carousel">
                                            <div class="carousel-inner">
                                                <div class="carousel-item active">
                                                    <img src="../assets/images/res/2.webp" class="d-block mx-auto img-fluid custom-img" alt="Image 1">
                                                </div>
                                                <div class="carousel-item">
                                                    <img src="../assets/images/res/2.webp" class="d-block mx-auto img-fluid custom-img" alt="Image 2">
                                                </div>
                                                <div class="carousel-item">
                                                    <img src="../assets/images/res/C5.jpg" class="d-block mx-auto img-fluid custom-img" alt="Image 3">
                                                </div>
                                            </div>
                                            <a class="carousel-control-prev" href="#carouselExample1" role="button" data-slide="prev">
                                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                                <span class="sr-only">Previous</span>
                                            </a>
                                            <a class="carousel-control-next" href="#carouselExample1" role="button" data-slide="next">
                                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                                <span class="sr-only">Next</span>
                                            </a>
                                        </div>
                                        <div class="card-body">
                                            <h1 class="card-title p-1  h2"> ROOM No : 001</h1>
                                            <hr>
                                            <h2 class="card-title"><i class="mdi mdi-account-multiple h-100"></i> OCCUPANTS 4/5</h2>
                                            <hr>
                                            <h3 class="card-title"> Description</h3>
                                            <ul class="list-arrow">
                                                <li>ROOM TYPE : BED SPACER</li>
                                                <li>LOWER BUNK BED</li>
                                                <li>₱ 1,300 /head</li>
                                                <li>NEAR WALTERMART, WESLEYAN UNIVERSITY - PHILIPPINES</li>
                                                <li>OWN METER OF WATER AND ELECTRICITY</li>
                                                <li>ATTACHED CR AND SINK</li>
                                            </ul>
                                             <div class="mt-3">
                                                <a   a class="btn  btn-gradient-primary btn-lg font-weight-medium auth-form-btn" href="Reservation.php">BOOK</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 stretch-card grid-margin">
                                    <div class="card card-img-holder">
                                        <div id="carouselExample1" class="carousel slide" data-ride="carousel">
                                            <div class="carousel-inner">
                                                <div class="carousel-item active">
                                                    <img src="../assets/images/res/2.webp" class="d-block mx-auto img-fluid custom-img" alt="Image 1">
                                                </div>
                                                <div class="carousel-item">
                                                    <img src="../assets/images/res/2.webp" class="d-block mx-auto img-fluid custom-img" alt="Image 2">
                                                </div>
                                                <div class="carousel-item">
                                                    <img src="../assets/images/res/C5.jpg" class="d-block mx-auto img-fluid custom-img" alt="Image 3">
                                                </div>
                                            </div>
                                            <a class="carousel-control-prev" href="#carouselExample1" role="button" data-slide="prev">
                                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                                <span class="sr-only">Previous</span>
                                            </a>
                                            <a class="carousel-control-next" href="#carouselExample1" role="button" data-slide="next">
                                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                                <span class="sr-only">Next</span>
                                            </a>
                                        </div>

                                        <div class="card-body">
                                            <h1 class="card-title p-1  h2"> ROOM No : 002</h1>
                                            <hr>
                                            <h2 class="card-title"><i class="mdi mdi-account-multiple h-100"></i> OCCUPANTS 4/5</h2>
                                            <hr>
                                            <h3 class="card-title"> Description</h3>
                                            <ul class="list-arrow">
                                                <li>ROOM TYPE : BED SPACER</li>
                                                <li>LOWER BUNK BED</li>
                                                <li>₱ 1,300 /head</li>
                                                <li>NEAR WALTERMART, WESLEYAN UNIVERSITY - PHILIPPINES</li>
                                                <li>OWN METER OF WATER AND ELECTRICITY</li>
                                                <li>ATTACHED CR AND SINK</li>
                                            </ul>
                                             <div class="mt-3">
                                                <a   a class="btn  btn-gradient-primary btn-lg font-weight-medium auth-form-btn" href="Reservation.php">BOOK</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                               <div class="col-md-4 stretch-card grid-margin">
                                    <div class="card card-img-holder">
                                        <div id="carouselExample1" class="carousel slide" data-ride="carousel">
                                            <div class="carousel-inner">
                                                <div class="carousel-item active">
                                                    <img src="../assets/images/res/2.webp" class="d-block mx-auto img-fluid custom-img" alt="Image 1">
                                                </div>
                                                <div class="carousel-item">
                                                    <img src="../assets/images/res/2.webp" class="d-block mx-auto img-fluid custom-img" alt="Image 2">
                                                </div>
                                                <div class="carousel-item">
                                                    <img src="../assets/images/res/C5.jpg" class="d-block mx-auto img-fluid custom-img" alt="Image 3">
                                                </div>
                                            </div>
                                            <a class="carousel-control-prev" href="#carouselExample1" role="button" data-slide="prev">
                                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                                <span class="sr-only">Previous</span>
                                            </a>
                                            <a class="carousel-control-next" href="#carouselExample1" role="button" data-slide="next">
                                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                                <span class="sr-only">Next</span>
                                            </a>
                                        </div>

                                        <div class="card-body">
                                            <h1 class="card-title p-1  h2"> ROOM No : 003</h1>
                                            <hr>
                                            <h2 class="card-title"><i class="mdi mdi-account-multiple h-100"></i> OCCUPANTS 4/5</h2>
                                            <hr>
                                            <h3 class="card-title"> Description</h3>
                                            <ul class="list-arrow">
                                                <li>ROOM TYPE : BED SPACER</li>
                                                <li>LOWER BUNK BED</li>
                                                <li>₱ 1,300 /head</li>
                                                <li>NEAR WALTERMART, WESLEYAN UNIVERSITY - PHILIPPINES</li>
                                                <li>OWN METER OF WATER AND ELECTRICITY</li>
                                                <li>ATTACHED CR AND SINK</li>
                                            </ul>
                                             <div class="mt-3">
                                                 <a   a class="btn  btn-gradient-primary btn-lg font-weight-medium auth-form-btn" href="Reservation.php">BOOK</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
               
                </div>
            </div>
            <!-- End Section 3 -->

        </div>
        <!-- page-body-wrapper ends -->
    </div>

  
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="assets/js/login.js"></script>
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/todolist.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- End custom js for this page -->
</body>
</html>
