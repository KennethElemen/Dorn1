<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Purple Admin</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="../assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="../assets/vendors/css/vendor.bundle.base.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="../assets/images/favicon.ico" />
 
</head>
<body>

   
    
      <div class="container-fluid page-body-wrapper full-page-wrapper">
    <!-- Section 1: Login Form -->
    <div class="content-wrapper d-flex align-items-center justify-content-center auth">
        <div class="row flex-grow">
            <!-- Center the form on the left -->
            <div class="col-lg-3 offset-lg-2">
                <div class="auth-form-light text-left p-4">
                    <h2 class="display-7" style="color: black;">Dorm Reservation</h2>
                    <form class="pt-3">
                        <div class="form-group">
                            <label for="exampleInputUsername1" style="color: black;">Full Name</label>
                            <input type="text" class="form-control" id="exampleInputUsername1" placeholder="Enter your full name">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1" style="color: black;">Email address</label>
                            <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter your email">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1" style="color: black;">Contact Number</label>
                            <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Enter your contact number">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputCheckIn" style="color: black;">Check-in Date</label>
                            <input type="date" class="form-control" id="exampleInputCheckIn">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputCheckOut" style="color: black;">Check-out Date</label>
                            <input type="date" class="form-control" id="exampleInputCheckOut">
                        </div>
                        <div class="form-group">
                            <label for="typeOfStay" style="color: black;">Type of Stay</label>
                            <select class="selectpicker form-control" data-live-search="true" id="typeOfStay">
                                <option value="Transient">Transient</option>
                                <option value="Another action">long-term</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="typeOfStay" style="color: black;">ROOM No</label>
                            <select class="selectpicker form-control" data-live-search="true" id="typeOfStay">
                                <option value="Transient">001</option>
                                <option value="Another action">002</option>
                            </select>
                        </div>
                        <div class="my-2 d-flex justify-content-between align-items-center">
                                                <div class="form-check">
                                                    <label class="form-check-label text-muted">
                                                        <input type="checkbox" class="form-check-input"> Terms and Agrement
                                                    </label>
                                                </div>
                                 
                         </div>
                        <button type="submit" class="btn btn-gradient-primary me-2">Submit</button>
                        <button type="reset" class="btn btn-light" >Cancel</button>
                    </form>
                </div>
            </div>

            <!-- Center the image on the right with left margin -->
             <div class="col-lg-6 ml-lg-3">
                <img src="../assets/images/res/Con1.png" class="img-fluid h-100 w-100">
            </div>

        </div>
    </div>
</div>

    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="../assets/js/dashboard.js"></script>
    <script src="../assets/js/todolist.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- End custom js for this page -->
</body>
</html>


