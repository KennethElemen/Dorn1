<?php

session_start(); 
// Check if 'user_id' is set in the session


?>
<?php include '../../includes/function/check_session.php'; ?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php'; ?>
  <body>
    <div class="container-scroller">
      <!-- partial:../../partials/_navbar.html -->
      <?php include '../topbar.php'; ?>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_sidebar.html -->
<?php include '../sidebar.php'; ?>
        <!-- partial -->
          <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title"> Dashboard</h3>
            </div>
            <div class="row">
                
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body" >
                    <h4 class="card-title">Announcements</h4>
                       <table class="table table-striped">
                           <thead>
                               <tr>
                                   <th>Date</th>
                                   <th></th>
                               </tr>
                           </thead>
                           <tbody>
                               <tr>
                                   <td>2023-11-29</td>
                                   <td>Your monthly bills due is on Novemeber 30, 2023.</td>
                               </tr>
                           </tbody>
                      </table>
                  </div>
                </div>
              </div>
                </div>
              </div>
          <!-- content-wrapper ends -->

          <!-- partial:../../partials/_footer.html -->
      <?php include '../footer.php'; ?>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
   <?php include '../scripts.php'; ?>
  </body>
</html>