<nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item nav-profile">
              <a href="#" class="nav-link">
                <div class="nav-profile-text d-flex flex-column">
                  <span class="font-weight-bold mb-2">Tenant </span>
                  <span class="text-secondary text-small">Tenant</span>
                </div>
                <i class="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
              </a>
            </li>
              <li class="nav-item">
                  <a class="nav-link" href="../tdashboard/tdashboard.php">
                      <span class="menu-title">Dashboard</span>
                      <i class="mdi mdi-home menu-icon"></i>
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="../tprofile/tprofile.php">
                      <span class="menu-title">Profile</span>
                      <i class="mdi mdi-account-multiple menu-icon"></i>
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="../tpayment/tpayment.php">
                      <span class="menu-title">Payment</span>
                      <i class="mdi mdi-wallet menu-icon"></i>
                  </a>
              </li>        
              <li class="nav-item">
                  <a class="nav-link" href="../taccount_sett/taccount_sett.php">
                      <span class="menu-title">Account Settings</span>
                      <i class="mdi mdi-settings menu-icon"></i>
                  </a>
              </li>
          </ul>
        </nav>