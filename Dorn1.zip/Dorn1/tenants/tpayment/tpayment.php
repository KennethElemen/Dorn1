<!DOCTYPE html>
<html lang="en">
<?php include '../head.php'; ?>
  <body>
    <div class="container-scroller">
      <?php include '../topbar.php'; ?>
      <div class="container-fluid page-body-wrapper">
<?php include '../sidebar.php'; ?>
          <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
            <button type="button" class="btn btn-primary btn-icon-text btn-flat btn-sm" data-toggle="modal" data-target="#add-payment">
                          <i class="mdi mdi-plus"></i>Add Payment
                      </button> 
            </div>
            <div class="row">
                
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body" >
                    <h4 class="card-title">Transaction History</h4>
                       <table class="table" id="example1">
                           <thead>
                               <tr>
                                   <th>Room Number</th>
                                   <th>Name</th>
                                   <th>Payment Method</th>
                                   <th>Amount</th>
                                   <th>Proof of Payment</th>
                                   <th>Balance</th>
                                   <th>Status</th>
                                   <th>Comments</th>
                                   <th>Date</th>
                               </tr>
                           </thead>
                           <tbody>
                               <tr>
                                   <td>Room01</td>
                                   <td>Herman Beck</td>
                                   <td>Online</td>
                                   <td>Php 2000</td>
                                   <td><button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#view-proof-of-payment">View</button></td>
                                   <td>Php 0.00</td>
                                   <td><label class="badge badge-success">Completed</label></td>
                                   <td></td>
                                   <td>30-11-2023</td>
                               </tr>
                           </tbody>
                      </table>
                  </div>
                </div>
              </div>
                
            </div>
          </div>
          
        <?php include '../modals.php'; ?>      
      <?php include '../footer.php'; ?>
        </div>
      </div>
    </div>
   <?php include '../scripts.php'; ?>
  </body>
</html>