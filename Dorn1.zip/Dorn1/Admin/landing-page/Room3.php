<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="stylesheet" href="../../assets/css/stye1.css">
<link rel="stylesheet" href="../../assets/css/1.css">
    <title>BOOKING FORM</title>
</head>
<body>
    <section class="landing-page">
    <div class="container1">
     <div class="sign-in1">
            <form class="form card1" action="bookedroom3.php" method="post">
                <div class="card_header1">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                        <path fill="none" d="M0 0h24v24H0z"></path>
                        <path fill="currentColor" d="M4 15h2v5h12V4H6v5H4V3a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-6zm6-4V8l5 4-5 4v-3H2v-2h8z"></path>
                    </svg>
                    <h1 class="form_heading">OCUPY ROOM-3</h1>
                </div>
                <div class="field">
                    <label for="username">Name</label>
                    <input class="input" name="name" type="text" placeholder="name" id="name" required>
                </div>
                  <div class="field">
                    <label for="username">Email</label>
                    <input class="input" name="email" type="text" placeholder="kalbo@gmail.com" id="email" required>
                </div>
                <div class="field">
                    <label for="initial_date">Initial Date</label>
                    <input class="input" name="initial_date" type="date" placeholder="Initial Date" id="initial_date"required>
                </div>
                <div class="field">
                    <label for="end_date">End Date</label>
                    <input class="input" name="end_date" type="date" placeholder="End Date" id="end_date" required>
                </div>
                <div class="field">
                    <label for="address">Address</label>
                    <input class="input" name="address" type="text" placeholder="Address" id="address" required>
                </div>
                <div class="field">
                    <label for="initial_payment">Initial Payment</label>
                    <input class="input" name="initial_payment" type="number" placeholder="Initial Payment" id="initial_payment" required>
                </div>
                <div class="field1">
                    <input type="checkbox" id="agree" name="agree" required>
                    <label for="agree">I agree to the terms and conditions</label>
                </div>
              <div class="field2"> 
                    <input class="button" type="submit" value="Confirm">
                </div>
            </form>
    </div>
    <div class="img-1">
        <video src="../../assets/images/res/Vid1.webm" autoplay muted loop></video>
    </div>
</div>
</section>
</body>
</html>