<nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item nav-profile">
              <a href="#" class="nav-link">
                <div class="nav-profile-text d-flex flex-column">
                  <span class="font-weight-bold mb-2">Admin </span>
                  <span class="text-secondary text-small">Administrator</span>
                </div>
                <i class="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
              </a>
            </li>
              <li class="nav-item">
                  <a class="nav-link" href="../dashboard/dashboard.php">
                      <span class="menu-title">Dashboard</span>
                      <i class="mdi mdi-home menu-icon"></i>
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="../customer_management/customer_management.php">
                      <span class="menu-title">Tenant</span>
                      <i class="mdi mdi-account-multiple menu-icon"></i>
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="../room_management/room_management.php">
                      <span class="menu-title">Room Management</span>
                      <i class="mdi mdi-houzz-box menu-icon"></i>
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="../payment/payment.php">
                      <span class="menu-title">Payment</span>
                      <i class="mdi mdi-wallet menu-icon"></i>
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="../announcement/announcement.php">
                      <span class="menu-title">Announcement</span>
                      <i class="mdi mdi-bell-ring menu-icon"></i>
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="../Chatbot/chatbot.php">
                      <span class="menu-title">Chatbot</span>
                      <i class="mdi mdi-bell-ring menu-icon"></i>
                  </a>
              </li>
        
              <li class="nav-item">
                  <a class="nav-link" href="../booking_management/booking_management.php">
                      <span class="menu-title">Booking</span>
                      <i class="mdi mdi-table menu-icon menu-icon"></i>
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="../income_report/income_report.php">
                      <span class="menu-title">Income Report</span>
                      <i class="mdi mdi-chart-bar menu-icon"></i>
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="../account_sett/account_sett.php">
                      <span class="menu-title">Account Settings</span>
                      <i class="mdi mdi-settings menu-icon"></i>
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="../website_sett/website_sett.php">
                      <span class="menu-title">Website Settings</span>
                      <i class="mdi mdi-wrench menu-icon"></i>
                  </a>
              </li>
          </ul>
        </nav>