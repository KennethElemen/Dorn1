<!DOCTYPE html>
<html lang="en">
<?php include '../head.php'; ?>
  <body>
    <div class="container-scroller">
      <?php include '../topbar.php'; ?>
      <div class="container-fluid page-body-wrapper">
        <?php include '../sidebar.php'; ?>
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header"></div>
            <div class="row">
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Tenant List</h4>
                    <div class="table-responsive">
                      <table class="table table-striped" id="example3">
                        <thead>
                          <tr>
                            <th>UserName</th>
                            <th>Name</th>
                            <th>Tenant Type</th>
                            <th>Room Type</th>
                            <th>Gender</th>
                            <th>Age</th>
                            <th>Address</th>
                            <th>Contact Number</th>
                            <th>Emergency Contact</th>
                            <th>Emergency Number</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th></th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>Tenant01</td>
                            <td>Herman Beck</td>
                            <td>Regular</td>
                            <td>Single</td>
                            <td>Male</td>
                            <td>20</td>
                            <td>Cabanatuan City, NE.</td>
                            <td>09123456789</td>
                            <td>Hermione Beck</td>
                            <td>09987654321</td>
                            <td>29-11-2023</td>
                            <td>29-01-2024</td>
                            <td><button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#edit-user">Edit</button>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        <?php include '../modals.php'; ?>
        <?php include '../footer.php'; ?>
        </div>
      </div>
    </div>
    <?php include '../scripts.php'; ?>
  </body>
</html>
