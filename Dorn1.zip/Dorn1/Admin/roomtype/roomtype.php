<!DOCTYPE html>
<html lang="en">
<?php include '../head.php'; ?>
  <body>
    <div class="container-scroller">
      <!-- partial:../../partials/_navbar.html -->
      <?php include '../topbar.php'; ?>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_sidebar.html -->
<?php include '../sidebar.php'; ?>
        <!-- partial -->
          <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
               <button type="button" class="btn btn-primary btn-icon-text btn-flat btn-sm" data-toggle="modal" data-target="#add-roomtype">
                          <i class="mdi mdi-plus"></i>Add Room Type
                      </button> 
            </div>
            <div class="row">
                
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body" >
                    <h4 class="card-title">Room Types</h4>
                       <table class="table" id="example1">
                           <thead>
                               <tr>
                                   <th>Room Type</th>
                                   <th></th>
                               </tr>
                           </thead>
                           <tbody>
                               <tr>
                                   <td>Single</td>
                                   <td><button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#edit-roomtype">Edit</button></td>
                               </tr>
                           </tbody>
                      </table>
                  </div>
                </div>
              </div>
                
            </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:../../partials/_footer.html -->
        <?php include '../modals.php'; ?>      
      <?php include '../footer.php'; ?>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
   <?php include '../scripts.php'; ?>
  </body>
</html>