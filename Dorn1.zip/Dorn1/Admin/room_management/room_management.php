<!DOCTYPE html>
<html lang="en">
<?php include '../head.php'; ?>
  <body>
    <div class="container-scroller">
      <!-- partial:../../partials/_navbar.html -->
      <?php include '../topbar.php'; ?>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_sidebar.html -->
<?php include '../sidebar.php'; ?>
        <!-- partial -->
          <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
               <button type="button" class="btn btn-primary btn-icon-text btn-flat btn-sm" data-toggle="modal" data-target="#add-room_management">
                          <i class="mdi mdi-plus"></i>Add Room Management
                      </button> 
                      <button type="button" class="btn btn-primary btn-icon-text btn-flat btn-sm" data-toggle="modal" data-target="#add-roomtype">
                          <i class="mdi mdi-plus"></i>Add Room Type
                      </button> 
            </div>
            <div class="row">
                
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body" >
                    <h4 class="card-title">Room Management</h4>
                       <table class="table table-striped" id="example3" style="font-size:10px;">
                           <thead>
                               <tr>
                                   <th>Room Number</th>
                                   <th>Room Name</th>
                                   <th>Description</th>
                                   <th>No. of Beds</th>
                                   <th>Images</th>
                                   <th>Rate Per Night</th>
                                   <th>Room Type</th>
                                   <th></th>
                               </tr>
                           </thead>
                           <tbody>
                               <tr>
                                   <td>001</td>
                                   <td>Regular</td>
                                   <td>With TV andd Aircon, Own CR</td>
                                   <td>2</td>
                                   <td><button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#view-room_management">View</button></td>
                                   <td>PHP 25.00</td>
                                   <td>Single</td>
                                   <td><button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#edit-room_management">Edit</button></td>
                               </tr>
                           </tbody>
                      </table>
                  </div>
                </div>
              </div>
                
            </div>
          </div>
        <?php include '../modals.php'; ?>      
      <?php include '../footer.php'; ?>
        </div>
      </div>
    </div>
   <?php include '../scripts.php'; ?>
  </body>
</html>