<div class="modal fade" id="add-roomtype">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Room Type</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
                       <div class="modal-body">
                <form role="form">
                    <div class="card-body">
                        <div class="row">
                        <div class="form-group col-md-12">
                            <label for="Room Type">Room Type</label>
                            <input type="text" class="form-control" id="Room Type" placeholder="Room Type">
                        </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal add-roomtype -->
<div class="modal fade" id="edit-roomtype">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Edit Room Type</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
                       <div class="modal-body">
                <form role="form">
                    <div class="card-body">
                        <div class="row">
                        <div class="form-group col-md-12">
                            <label for="Room Type">Room Type</label>
                            <input type="text" class="form-control" id="Room Type" placeholder="Room Type">
                        </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal edit-roomtype -->
<div class="modal fade" id="add-room_management">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Room Management</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
                       <div class="modal-body">
                <form role="form">
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label for="Room Number">Room Number</label>
                                <input type="text" class="form-control" id="Room Number" placeholder="Room Number">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="Room Name">Room Name</label>
                                <input type="text" class="form-control" id="Room Name" placeholder="Room Name">
                            </div>
                            <div class="form-group col-md-12">
                                <label for="Description">Description</label>
                                <textarea class="form-control" id="Description" rows="2"></textarea>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="No. of Beds">No. of Beds</label>
                                <input type="number" class="form-control" id="No. of Beds" placeholder="No. of Beds">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="Images">Choose Images</label>
                                <input type="file" class="form-control" id="Images" placeholder="Images" multiple>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="Rate per Night">Rate per Night</label>
                                <input type="number" class="form-control" id="Rate per Night" placeholder="Rate per Night">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="Room Type">Room Type</label>
                                <select class="form-control">
                                    <option>Category1</option>
                                    <option>Category2</option>
                                    <option>Category3</option>
                                    <option>Category4</option>
                                </select>
                            </div>
                            </div>
                        <button type="submit" class="btn btn-primary ">Submit</button>
                        <button type="button" class="btn btn-default " data-dismiss="modal">Cancel</button> 
                        
                    </div>
                    <!-- /.card-body -->
                    
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal add-room_management -->
<div class="modal fade" id="edit-room_management">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Edit Room Management</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
                       <div class="modal-body">
                <form role="form">
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label for="Room Number">Room Number</label>
                                <input type="text" class="form-control" id="Room Number" placeholder="Room Number">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="Room Name">Room Name</label>
                                <input type="text" class="form-control" id="Room Name" placeholder="Room Name">
                            </div>
                            <div class="form-group col-md-12">
                                <label for="Description">Description</label>
                                <textarea class="form-control" id="Description" rows="2"></textarea>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="No. of Beds">No. of Beds</label>
                                <input type="number" class="form-control" id="No. of Beds" placeholder="No. of Beds">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="Images">Choose Images</label>
                                <input type="file" class="form-control" id="Images" placeholder="Images" multiple>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="Rate per Night">Rate per Night</label>
                                <input type="number" class="form-control" id="Rate per Night" placeholder="Rate per Night">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="Room Type">Room Type</label>
                                <select class="form-control">
                                    <option>Category1</option>
                                    <option>Category2</option>
                                    <option>Category3</option>
                                    <option>Category4</option>
                                </select>
                            </div>
                            </div>
                        <button type="submit" class="btn btn-primary ">Submit</button>
                        <button type="button" class="btn btn-default " data-dismiss="modal">Cancel</button> 
                        
                    </div>
                    <!-- /.card-body -->
                    
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal edit-room_management -->
<div class="modal fade" id="view-room_management">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Room Management Images</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="card-body">
                    <div class="w3-content" style="max-width:800px">
                        <img class="mySlides" src="../../pages/images/aae2fff8fff75e8aa26c1306f2425244012897b6.jpg" style="width:100%">
                        <img class="mySlides" src="../../pages/images/download.jfif" style="width:100%">
                        <img class="mySlides" src="../../pages/images/1573116959_guestroom-mob_2.jpg" style="width:100%">
                    </div>

                    <div class="w3-center">
                        <div class="w3-section">
                            <button class="w3-button w3-light-grey" onclick="plusDivs(-1)">❮ Prev</button>
                            <button class="w3-button w3-light-grey" onclick="plusDivs(1)">Next ❯</button>
                        </div>
                        <button class="w3-button demo" onclick="currentDiv(1)">1</button> 
                        <button class="w3-button demo" onclick="currentDiv(2)">2</button> 
                        <button class="w3-button demo" onclick="currentDiv(3)">3</button> 
                    </div>
                    <button type="button" class="btn btn-default " data-dismiss="modal">Close</button>
                </div>
                <!-- /.card-body -->
            </div>
        </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal view-room_management -->
<div class="modal fade" id="add-customer">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Tenant</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
                       <div class="modal-body">
                <form role="form">
                    <div class="card-body">
                        <div class="row">
                        <div class="form-group col-md-12">
                            <label for="Full Name">Name</label>
                            <input type="text" class="form-control" id="Full Name" placeholder="Full Name">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Contact Number">Contact Number</label>
                            <input type="text" class="form-control" id="Contact Number" placeholder="Contact Number">
                        </div>
                        <div class="form-group col-md-6">
                            <label for="Age">Age</label>
                            <input type="number" class="form-control" id="Age" placeholder="Age">
                        </div>
                        <div class="form-group col-md-12">
                            <label for="Full Name">Guardian</label>
                            <input type="text" class="form-control" id="Full Name" placeholder="Full Name">
                        </div>
                        <div class="form-group col-md-12">
                            <label for="Contact Number">Guardian's Contact Number</label>
                            <input type="text" class="form-control" id="Contact Number" placeholder="Contact Number">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Address">Address</label>
                            <input type="text" class="form-control" id="Address" placeholder="Address">
                        </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal add-customer -->
<div class="modal fade" id="edit-customer">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Edit Tenant Info</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
                       <div class="modal-body">
                <form role="form">
                    <div class="card-body">
                        <div class="row">
                        <div class="form-group col-md-12">
                            <label for="Full Name">Name</label>
                            <input type="text" class="form-control" id="Full Name" placeholder="Full Name">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Contact Number">Contact Number</label>
                            <input type="text" class="form-control" id="Contact Number" placeholder="Contact Number">
                        </div>
                        <div class="form-group col-md-6">
                            <label for="Age">Age</label>
                            <input type="number" class="form-control" id="Age" placeholder="Age">
                        </div>
                        <div class="form-group col-md-12">
                            <label for="Full Name">Guardian</label>
                            <input type="text" class="form-control" id="Full Name" placeholder="Full Name">
                        </div>
                        <div class="form-group col-md-12">
                            <label for="Contact Number">Guardian's Contact Number</label>
                            <input type="text" class="form-control" id="Contact Number" placeholder="Contact Number">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Address">Address</label>
                            <input type="text" class="form-control" id="Address" placeholder="Address">
                        </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal edit-customer -->
<div class="modal fade" id="add-guardian">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Guardian</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
                       <div class="modal-body">
                <form role="form">
                    <div class="card-body">
                        <div class="row">
                        <div class="form-group col-md-12">
                            <label for="First Name">Full Name</label>
                            <input type="text" class="form-control" id="First Name" placeholder="First Name">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Address">Address</label>
                            <input type="text" class="form-control" id="Address" placeholder="Address">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Contact">Contact</label>
                            <input type="number" class="form-control" id="Contact" placeholder="Contact">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Ward/Customer">Ward/Customer</label>
                            <select class="form-control">
                                    <option>Category1</option>
                                    <option>Category2</option>
                                    <option>Category3</option>
                                    <option>Category4</option>
                                </select>
                        </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal add-guardian -->
<div class="modal fade" id="edit-guardian">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Adeditd Guardian</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
                       <div class="modal-body">
                <form role="form">
                    <div class="card-body">
                        <div class="row">
                        <div class="form-group col-md-12">
                            <label for="First Name">Full Name</label>
                            <input type="text" class="form-control" id="First Name" placeholder="First Name">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Address">Address</label>
                            <input type="text" class="form-control" id="Address" placeholder="Address">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Contact">Contact</label>
                            <input type="number" class="form-control" id="Contact" placeholder="Contact">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Ward/Customer">Ward/Customer</label>
                            <select class="form-control">
                                    <option>Category1</option>
                                    <option>Category2</option>
                                    <option>Category3</option>
                                    <option>Category4</option>
                                </select>
                        </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal add-guardian -->
<div class="modal fade" id="add-booking">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Booking</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
                       <div class="modal-body">
                <form role="form">
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                            <label for="Room">Room</label>
                            <select class="form-control">
                                    <option>Category 1</option>
                                    <option>Category 2</option>
                                    <option>Category 3</option>
                                    <option>Category 4</option>
                            </select>
                        </div>
                        <div class="form-group col-md-12">
                            <label for="Customer">Customer</label>
                            <select class="form-control">
                                    <option>Juliana</option>
                                    <option>Alexa</option>
                                    <option>Joe</option>
                                    <option>Corden</option>
                            </select>
                        </div>
                            <div class="form-group col-md-12">
                                <label for="Started Date">Started Date</label>
                                <input type="date" class="form-control" id="Started Date" placeholder="Started Date">
                            </div> 
                            <div class="form-group col-md-12">
                                <label for="End Date">End Date</label>
                                <input type="date" class="form-control" id="End Date" placeholder="End Date">
                            </div>
                            <div class="form-group col-md-12">
                                <label for="Total Amount">Total Amount</label>
                                <input type="number" class="form-control" id="Total Amount" placeholder="PHP">
                            </div>
                            <div class="form-group col-md-12">
                                <label for="Status">Status</label>
                                <input type="text" class="form-control" id="Status" placeholder="Status">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal add-booking -->
<div class="modal fade" id="edit-booking">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Edit Booking</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
                       <div class="modal-body">
                <form role="form">
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <label for="Room">Room</label>
                                <select class="form-control">
                                    <option>Category 1</option>
                                    <option>Category 2</option>
                                    <option>Category 3</option>
                                    <option>Category 4</option>
                                </select>
                        </div>
                        <div class="form-group col-md-12">
                            <label for="Customer">Customer</label>
                            <select class="form-control">
                                    <option>Juliana</option>
                                    <option>Alexa</option>
                                    <option>Joe</option>
                                    <option>Corden</option>
                            </select>
                        </div>
                            <div class="form-group col-md-12">
                                <label for="Started Date">Started Date</label>
                                <input type="date" class="form-control" id="Started Date" placeholder="Started Date">
                            </div> 
                            <div class="form-group col-md-12">
                                <label for="End Date">End Date</label>
                                <input type="date" class="form-control" id="End Date" placeholder="End Date">
                            </div>
                            <div class="form-group col-md-12">
                                <label for="Total Amount">Total Amount</label>
                                <input type="number" class="form-control" id="Total Amount" placeholder="PHP">
                            </div>
                            <div class="form-group col-md-12">
                                <label for="Status">Status</label>
                                <input type="text" class="form-control" id="Status" placeholder="Status">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal edit-booking -->
<div class="modal fade" id="add-payment">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add Payment</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
                       <div class="modal-body">
                <form role="form">
                    <div class="card-body">
                        <div class="row">
                        <div class="form-group col-md-12">
                            <label for="Start Date">Start Date</label>
                            <input type="date" class="form-control" id="Start Date" placeholder="Start Date">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="End Date">End Date</label>
                            <input type="date" class="form-control" id="End Date" placeholder="End Date">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Payment Amount">Payment Amount</label>
                            <input type="number" class="form-control" id="Payment Amount" placeholder="PHP">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Discount">Discount</label>
                            <input type="number" class="form-control" id="Discount" placeholder="PHP">
                        </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal add-payment -->
<div class="modal fade" id="add-user">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add User</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form">
                    <div class="card-body">
                        <div class="row">
                        <div class="form-group col-md-12">
                            <label for="User Name">User Name</label>
                            <input type="text" class="form-control" id="User Name" placeholder="User Name">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Password">Password</label>
                            <input type="text" class="form-control" id="Password" placeholder="Password">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Contact Name">Name</label>
                            <input type="text" class="form-control" id="Contact Name" placeholder="Name">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Contact Number">Contact Number</label>
                            <input type="text" class="form-control" id="Contact Number" placeholder="Contact Number">
                        </div>
                            <div class="form-group col-md-12">
                            <label for="Account Type">Account Type</label>
                            <input type="text" class="form-control" id="Account Type" placeholder="Account Type">
                        </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button> 
                    </div>
                    <!-- /.card-body -->
                    
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal add-user -->
<div class="modal fade" id="edit-user">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Edit Tenant Info</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form role="form">
                    <div class="card-body">
                        <div class="row">
                        <div class="col-md-6">
                          <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Name</label>
                            <div class="col-sm-9">
                            <input class="form-control" placeholder="Full Name" />
                            </div>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Tenant Type</label>
                            <div class="col-sm-4">
                              <div class="form-check">
                                <label class="form-check-label">
                                  <input type="radio" class="form-check-input" name="membershipRadios" id="membershipRadios1" value="" checked> Regular </label>
                              </div>
                            </div>
                            <div class="col-sm-5">
                              <div class="form-check">
                                <label class="form-check-label">
                                  <input type="radio" class="form-check-input" name="membershipRadios" id="membershipRadios2" value="option2"> Transient </label>
                              </div>
                            </div>
                          </div>
                        </div>          
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Room Type</label>
                            <div class="col-sm-9">
                            <input class="form-control" placeholder="Room Type" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Start Date</label>
                            <div class="col-sm-4">
                            <input type="date" id="start-date" name="start-date">
                            </div>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group row">
                            <label class="col-sm-3 col-form-label">End Date</label>
                            <div class="col-sm-4">
                            <input type="date" id="end-date" name="end-date">
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Gender</label>
                            <div class="col-sm-9">
                              <select class="form-control">
                                <option>Male</option>
                                <option>Female</option>
                              </select>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Age</label>
                            <div class="col-sm-9">
                              <input class="form-control" placeholder="Age" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Address</label>
                            <div class="col-sm-9">
                            <input class="form-control" placeholder="Address" />
                            </div>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Contact Number</label>
                            <div class="col-sm-9">
                            <input class="form-control" placeholder="Contact Number" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <p class="card-description"> Emergency Contact </p>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Name</label>
                            <div class="col-sm-9">
                            <input class="form-control" placeholder="Full Name" />
                            </div>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Contact Number</label>
                            <div class="col-sm-9">
                            <input class="form-control" placeholder="Emergency Number" />
                            </div>
                          </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button> 
                    </div>
                    </div>
                    <!-- /.card-body -->
                    
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal edit-user -->