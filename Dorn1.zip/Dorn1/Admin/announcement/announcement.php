<?php
// Admin/dashboard/dashboard.php

// Include the check_session.php file to enforce authentication
require_once('../../includes/functions/check_session.php');

// The rest of your admin dashboard code goes here
?>

<!DOCTYPE html>
<html lang="en">
<?php include '../head.php'; ?>
  <body>
    <div class="container-scroller">
      <!-- partial:../../partials/_navbar.html -->
      <?php include '../topbar.php'; ?>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_sidebar.html -->
<?php include '../sidebar.php'; ?>
        <!-- partial -->
          <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
               <button type="button" class="btn btn-primary btn-icon-text btn-flat btn-sm" data-toggle="modal" data-target="#add-user">
                          <i class="mdi mdi-plus"></i>Add User
                      </button> 
            </div>
            <div class="row">
                
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body" >
                    <h4 class="card-title">Tenant List</h4>
                       <table class="table" id="example1">
                           <thead>
                               <tr>
                                   <th>Name</th>
                                   <th>Contact Number</th>
                                   <th>Age</th>
                                   <th>Guardian</th>
                                   <th>Guardian's Contact Number</th>
                                   <th>Address</th>
                                   <th></th>
                               </tr>
                           </thead>
                           <tbody>
                               <tr>
                                   <td>Maria Dela Cruz</td>
                                   <td>09524789654</td>
                                   <td>16</td>
                                   <td>Marites Dela Cruz</td>
                                   <td>09876543222</td>
                                   <td>Brgy. De La Paz, Cadiz City</td>
                                   <td><button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#edit-customer">Edit</button></td>
                               </tr>
                           </tbody>
                      </table>
                  </div>
                </div>
              </div>
                
            </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:../../partials/_footer.html -->
        <?php include '../modals.php'; ?>      
      <?php include '../footer.php'; ?>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
   <?php include '../scripts.php'; ?>
  </body>
</html>