<!DOCTYPE html>
<html lang="en">
<?php include '../head.php'; ?>
  <body>
    <div class="container-scroller">
      <!-- partial:../../partials/_navbar.html -->
      <?php include '../topbar.php'; ?>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_sidebar.html -->
   <?php include '../sidebar.php'; ?>



<script src="https://cdn.jsdelivr.net/npm/jquery@3.4.1/dist/jquery.min.js"></script>
<script src="../../assests/js/evo-calendar.min.js"></script>


    <div id="calendar" class="calendar"></div>




<script>
    $(document).ready(function() {
    $('#calendar').evoCalendar({
       
    })
})

</script>



<?php include '../modals.php'; ?>      
      <?php include '../footer.php'; ?>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
   <?php include '../scripts.php'; ?>



</body>
</html>