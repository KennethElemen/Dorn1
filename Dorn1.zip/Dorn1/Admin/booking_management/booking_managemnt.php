<!DOCTYPE html>
<html lang="en">
<?php include '../head.php'; ?>
  <body>
    <div class="container-scroller">
      <!-- partial:../../partials/_navbar.html -->
      <?php include '../topbar.php'; ?>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_sidebar.html -->
<?php include '../sidebar.php'; ?>
        <!-- partial -->
          <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
               <button type="button" class="btn btn-primary btn-icon-text btn-flat btn-sm" data-toggle="modal" data-target="#add-booking">
                          <i class="mdi mdi-plus"></i>Add Booking
                      </button> 
            </div>
            <div class="row">
                
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body" >
                    <h4 class="card-title">Booking Management</h4>
                       <table class="table table-striped" id="example1">
                           <thead>
                               <tr>
                                   <th>Room</th>
                                   <th>Customer</th>
                                   <th>Started Date</th>
                                   <th>End Date</th>
                                   <th>Total Amount</th>
                                   <th>Status</th>
                                   <th>Booked By</th>
                                   <th></th>
                               </tr>
                           </thead>
                           <tbody>
                               <tr>
                                   <td>Single</td>
                                   <td>Juliana</td>
                                   <td>10-17-2019</td>
                                   <td>11-12-2016</td>
                                   <td>PHP 502.00</td>
                                   <td>OK</td>
                                   <td>User</td>
                                   <td><button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#edit-booking">Edit</button>
                                   <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#add-payment">Add Payment</button></td>
                               </tr>
                           </tbody>
                      </table>
                  </div>
                </div>
              </div>
                
            </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:../../partials/_footer.html -->
        <?php include '../modals.php'; ?>      
      <?php include '../footer.php'; ?>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
   <?php include '../scripts.php'; ?>
  </body>
</html>