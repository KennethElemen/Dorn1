<!DOCTYPE html>
<html lang="en">
<?php include '../head.php'; ?>
<script src="//code.tidio.co/rigk6wllgp396rgqayzic87xr1qljmk8.js" async></script>
  <body>
    <div class="container-scroller">
      <!-- partial:../../partials/_navbar.html -->
      <?php include '../topbar.php'; ?>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_sidebar.html -->
<?php include '../sidebar.php'; ?>
        <!-- partial -->
          <div class="main-panel">
          <div class="content-wrapper">
          <div class="row flex-grow-1">
<iframe src="https://www.tidio.com/panel/settings/live-chat/appearance" style="height: 100vh; width: 100%; overflow:hidden;"  frameborder="0"></iframe>
          </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:../../partials/_footer.html -->
        <?php include '../modals.php'; ?>      
      <?php include '../footer.php'; ?>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
   <?php include '../scripts.php'; ?>
  </body>
</html>
