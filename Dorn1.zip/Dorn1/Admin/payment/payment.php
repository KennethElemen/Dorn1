<!DOCTYPE html>
<html lang="en">
<?php include '../head.php'; ?>
<style>
    .form-control {
      width: 150px;
    }
  </style>
  <body>
    <div class="container-scroller">
      <?php include '../topbar.php'; ?>
      <div class="container-fluid page-body-wrapper">
<?php include '../sidebar.php'; ?>
          <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
            </div>
            <div class="row">
                
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body" >
                    <h4 class="card-title">Transaction History</h4>
                       <table class="table" id="example1">
                           <thead>
                               <tr>
                                   <th>Room Number</th>
                                   <th>Name</th>
                                   <th>Payment Method</th>
                                   <th>Amount</th>
                                   <th>Proof of Payment</th>
                                   <th>Balance</th>
                                   <th>Status</th>
                                   <th>Comments</th>
                                   <th>Date</th>
                               </tr>
                           </thead>
                           <tbody>
                               <tr>
                                   <td>Room01</td>
                                   <td>Herman Beck</td>
                                   <td>Online</td>
                                   <td>Php 2000</td>
                                   <td><button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#view-proof-of-payment">View</button></td>
                                   <td>Php 0.00</td>
                                    <td>
                                    <select class="form-control" onchange="changeColor(this)">
                                      <option value="pending">Pending</option>
                                      <option value="completed">Completed</option>
                                      <option value="rejected">Rejected</option>
                                    </select>
                                  </td>
                                  <td>
                                  <textarea name="" id="input" class="form-control" rows="3"></textarea>
                                  </td>
                                  <td>30-11-2023</td>
                               </tr>
                               <tr>
                                   <td>Room02</td>
                                   <td>Shaina Flores</td>
                                   <td>Online</td>
                                   <td>Php 2000</td>
                                   <td><button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#view-proof-of-payment">View</button></td>
                                   <td>Php 0.00</td>
                                   <td>
                                   <select class="form-control" onchange="changeColor(this)">
                                      <option value="pending">Pending</option>
                                      <option value="completed">Completed</option>
                                      <option value="rejected">Rejected</option>
                                    </select>
                                   <td>
                                  <textarea name="" id="input" class="form-control" rows="3"></textarea>
                                  </td>
                                  <td>30-11-2023</td>
                               </tr>
                           </tbody>
                      </table>
                  </div>
                </div>
              </div>
                
            </div>
          </div>
        <?php include '../modals.php'; ?>      
      <?php include '../footer.php'; ?>
        </div>
      </div>
    </div>
    <script>
  function changeColor(selectElement) {
    var selectedOption = selectElement.options[selectElement.selectedIndex].value;

    var statusColors = {
      'pending': '#E69940',
      'completed': '#40e2c0',
      'rejected': '#E25c3d'
    };

    selectElement.style.backgroundColor = statusColors[selectedOption] || '';

    selectElement.style.color = selectedOption ? 'white' : '';

    var row = selectElement.closest('tr');
    var otherSelects = row.querySelectorAll('.form-control');
    otherSelects.forEach(function (otherSelect) {
      if (otherSelect !== selectElement) {
        otherSelect.style.backgroundColor = '';
        otherSelect.style.color = ''; 
      }
    });
  }
</script>


   <?php include '../scripts.php'; ?>
  </body>
</html>