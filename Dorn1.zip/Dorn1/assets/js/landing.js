function openBookingForm3() {
    window.open('landing-page/Room3.html', '_blank');
}


function openBookingForm3() {
    window.open('landing-page/Room3.html', '_blank');
}

 function openBookingForm3() {
    window.open('landing-page/Room3.html', '_blank');
}
