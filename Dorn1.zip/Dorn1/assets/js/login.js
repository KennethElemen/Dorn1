function loginFunction() {
    // Get the values from the username and password inputs
    var username = document.getElementById("usernameInput").value;
    var password = document.getElementById("passwordInput").value;

    // Check the username and password
    if (username === "admin" && password === "admin") {
      // Redirect to the admin dashboard
      window.location.href = "Admin/dashboard/dashboard.php";
    } else if (username === "sharmaine" && password === "123") {
      // Redirect to the tenant dashboard
      window.location.href = "tenants/tdashboard/tdashboard.php";
    } else {
      // Handle incorrect credentials (you can show an error message, etc.)
      alert("Incorrect username or password. Please try again.");
    }
  }