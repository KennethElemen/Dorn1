<?php
// login.php

require_once('includes/config/dbconn.php'); // Include your database connection file

function login($email, $password, $conn)
{
    $email = mysqli_real_escape_string($conn, $email);
    $password = mysqli_real_escape_string($conn, $password);

    $adminQuery = "SELECT * FROM admins WHERE email='$email' AND password='$password'";
    $adminResult = mysqli_query($conn, $adminQuery);

    $tenantQuery = "SELECT * FROM tenants WHERE email='$email' AND password='$password'";
    $tenantResult = mysqli_query($conn, $tenantQuery);

    if (mysqli_num_rows($adminResult) > 0) {
        $_SESSION['AdminID'] = $adminID; // Set the actual AdminID here
        $_SESSION['user_type'] = 'admin';
        return "admin";
    } elseif (mysqli_num_rows($tenantResult) > 0) {
        $_SESSION['TenantID'] = $tenantID; // Set the actual TenantID here
        $_SESSION['user_type'] = 'tenant';
        return "tenant";
    } else {
        return false;
    }
}

session_start(); // Start the session

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['Email'];
    $password = $_POST['Password'];

    $userType = login($email, $password, $conn);

   if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['Email'];
    $password = $_POST['Password'];

    $userType = login($email, $password, $conn);

    if ($userType === "admin") {
        echo "Redirecting to admin dashboard";
        $_SESSION['user_type'] = 'admin'; // Set session variable for admin user
        $_SESSION['AdminID'] = $adminID; // Set the actual AdminID here
        header("Location: /Dorn1/Admin/dashboard/dashboard.php");
        exit();
    } elseif ($userType === "tenant") {
        echo "Redirecting to tenant dashboard";
        $_SESSION['user_type'] = 'tenant'; // Set session variable for tenant user
        header("Location: /Dorn1/tenants/tdashboard/tdashboard.php");
        exit();
    } else {
        echo "Invalid credentials. Please try again.";
    }
}
}
?>
