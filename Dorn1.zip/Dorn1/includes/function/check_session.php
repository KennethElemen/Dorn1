<?php
session_start();

// Check if 'AdminID' is set in the session
if (isset($_SESSION['AdminID']) && $_SESSION['user_type'] === 'admin') {
    // Redirect admin to the admin dashboard
    header("Location: Admin/dashboard/dashboard.php");
    exit();
} elseif (isset($_SESSION['TenantID']) && $_SESSION['user_type'] === 'tenant') {
    // Redirect tenant to the tenant dashboard
    header("Location: tenants/tdashboard/tdashboard.php");
    exit();
} else {
    // Redirect to the error page if no valid user is logged in
    header("Location: ../../errorpage/error.php");
    exit();
}
?>
